var emojis = ['😠','😦','😑','😀','😍'];

$(".emojiInput").mousemove(function(){
    var i = $(this).val();
    $("#star").html(emojis[i]);
});

