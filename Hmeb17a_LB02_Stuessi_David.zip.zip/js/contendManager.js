'use strict';
var emojis = ['😠','😦','😑','😀','😍'];

$(".emojiInput").mousemove(function(){
    var i = $(this).val();
    $("#star").html(emojis[i]);
});

let cleanAndSetUP = function(htmlFileName){

    $(' main ').children().remove('*');
    $(' main ').load(htmlFileName);

};
var baseUrl = "http://localhost:8080";

let getAllGenres = function () {
    var returnString = '';

    var promise = makePromise('/genres');
    promise.then(
        data => {
            JSON.parse(data).forEach(function (genre){
                returnString += "<li><a class='genre'>" + genre +"</a></li>";
            });
            $('#genre').append(returnString);

        },
        error => {
            console.log("Promise rejected.");
            console.log(error.message);
        }
    );
};

let getMoviesFromGenre = function(genre) {
    var emojis2 = ['😠','😦','😑','😀','😍'];
    var htmlConten = '<div class="movieList">';
    var promise = makePromise('/movies/genre/' + genre);
    promise.then(
        data => {
            var movies = JSON.parse(data);
            movies.forEach(function (movie) {
                var title = movie.movieTitle;
                var src = movie.imgSrc;
                var desc = movie.movieDescription;
                var rating = movie.rating;
                var smile = emojis2[rating-1];



                htmlConten += "<div class=\"listmovie\">\n" +
                    "    <img src=\"" + src + "\" class=\"listMovie\">\n" +
                    "\n" +
                    "    <h1 class=\"movieTitle\">" + title + "</h1>\n" +
                    "    <div>\n" +
                    "    <p class=\"description\">" + desc + "</p>\n" +
                    "    </div>\n" +
                    "<div class=\"col-sm-3\">\n" +
                    "                <div class=\"emoji\">" + smile + "</div>\n" +
                    "            </div>" +
                    "</div>";

            });
            htmlConten += "</div>";


        }
    ).then(() => {

        $(' main ').append(htmlConten);

    });
};

let getRandomMovie = function () {

    var promis = makePromise('/movies/random');
    getMovie(promis);

};

let getMovieByName = function (movieTitle){
    var promis = makePromise('/movies/'+movieTitle);
    getMovie(promis);
};

let getMovie = function(promis){
    var emojis = ['😠','😦','😑','😀','😍'];
    var movieContend = "";
    promis.then(
        data => {
            var movie = JSON.parse(data);

            var title = movie[0].movieTitle;
            var src = movie[0].imgSrc;
            var desc = movie[0].movieDescription;


            movieContend = "<div class=\"movie\">\n" +
                "        <img src=\""+ src +"\"\n" +
                "             class=\"resize\">\n" +
                "        <h1 class=\"movieTitle\">"+ title+ "</h1>\n" +
                "        <p class=\"description\">"+ desc+ "</p>\n" +
                "        <div id=\"reviewForm\"></div>\n" +
                "    </div>\n";
            movieContend += "<div id=\"reviewContainer\">";
            var nextpromis = makePromise("/reviews/" + title);
            nextpromis.then(data=>{
                var reviews = JSON.parse(data);
                reviews.forEach(function(review){
                    var user = review.user;
                    var rating = review.rating;
                    var reviewText = review.reviewText;
                    var smile = emojis[rating-1];
                    movieContend += "<div class=\"review\">\n" +
                        "        <div class=\"row\">\n" +
                        "            <div class=\"col-sm-3\">\n" +
                        "                <div class=\"emoji\">" + smile + "</div>\n" +
                        "            </div>\n" +
                        "            <div class=\"col-sm-9\">\n" +
                        "                <h5 class=\"user\">" + user + "</h5>\n" +
                        "                <p class=\"reviewText\">" + reviewText + "</p>\n" +
                        "            </div>\n" +
                        "        </div></div>";
                });
                movieContend += "</div>"
            }).then(()=>{
                $('main').append(movieContend);
                $('#reviewForm').load('reviewmodal.html');
            })
        });
};



let makePromise = function (url) {


    return new Promise((resolve, reject) => {
        let request = new XMLHttpRequest();

        request.open("GET", baseUrl + url);
        request.onload = () => {
            if (request.status === 200) {
                resolve(request.response);
            } else {
                reject(Error(request.statusText));
            }
        };
        request.onerror = () => {
            reject(Error("Error fetching data."));
        };
        request.send();

    });
};




