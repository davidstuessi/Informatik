var open = false;
$(document).ready(function () {

    $('#footerSlideButton').click(function () {
        console.log('footer got clicked');
        if(open === false) {
            $('.navbar-fixed-bottom').animate({ height: '200px' });
            $(this).css('backgroundPosition', 'bottom left');
            open = true;
        } else {
            $('.navbar-fixed-bottom').animate({ height: '0px' });
            $(this).css('backgroundPosition', 'top left');
            open = false;
        }
    });     $(this).text($(this).text() === 'close' ? 'open' : 'close');

});